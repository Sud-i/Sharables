import winreg

def evaluate_registry_key(reg_key, target_value, operator='eq'):
    """
    Evaluate the value of a Windows registry key.

    Args:
        reg_key (str): Full registry key path with hive, e.g.,
                       "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\CachedLogonsCount"
        target_value (int or str): The value to compare against.
        operator (str): One of 'eq', 'gte', 'lte', 'gt', 'lt'.

    Returns:
        str: 'PASS', 'FAIL', 'UNKNOWN', or 'SKIP'
    """

    hive_map = {
        "HKEY_LOCAL_MACHINE": winreg.HKEY_LOCAL_MACHINE,
        "HKEY_CURRENT_USER": winreg.HKEY_CURRENT_USER,
        "HKEY_CLASSES_ROOT": winreg.HKEY_CLASSES_ROOT,
        "HKEY_USERS": winreg.HKEY_USERS,
        "HKEY_CURRENT_CONFIG": winreg.HKEY_CURRENT_CONFIG,
    }

    try:
        parts = reg_key.split("\\")
        hive_name = parts[0]
        value_name = parts[-1]
        subkey_path = "\\".join(parts[1:-1])

        hive = hive_map.get(hive_name)
        if hive is None:
            return "UNKNOWN"

        with winreg.OpenKey(hive, subkey_path) as key:
            value, _ = winreg.QueryValueEx(key, value_name)

            # Cast to same type for comparison
            if isinstance(target_value, int):
                value = int(value)
            elif isinstance(target_value, str):
                value = str(value)

            # Evaluate condition
            if operator == 'eq':
                return "PASS" if value == target_value else "FAIL"
            elif operator == 'gte':
                return "PASS" if value >= target_value else "FAIL"
            elif operator == 'lte':
                return "PASS" if value <= target_value else "FAIL"
            elif operator == 'gt':
                return "PASS" if value > target_value else "FAIL"
            elif operator == 'lt':
                return "PASS" if value < target_value else "FAIL"
            else:
                return "UNKNOWN"

    except FileNotFoundError:
        return "SKIP"
    except Exception:
        return "UNKNOWN"
