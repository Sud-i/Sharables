import subprocess
import shutil
import os

def export_security_policy():
    try:
        # Define the source and target paths
        temp_dir = r"C:\temp"
        source_file = os.path.join(temp_dir, "secpol.cfg")
        target_file = os.path.join(os.getcwd(), "secpol.cfg")

        # Create temp directory if it doesn't exist
        os.makedirs(temp_dir, exist_ok=True)

        print("[*] Exporting security policy using secedit...")

        # Run the secedit export command
        result = subprocess.run(
            ["secedit", "/export", "/cfg", source_file],
            capture_output=True,
            text=True,
            check=False
        )

        if result.returncode != 0:
            print(f"[!] Failed to export security policy.\n{result.stderr.strip()}")
            return

        if not os.path.exists(source_file):
            print("[!] Exported file not found. The operation may have failed due to permission issues.")
            return

        # Copy the .cfg file to the current working directory
        shutil.copy2(source_file, target_file)
        print(f"[+] Security policy exported and copied to: {target_file}")

    except PermissionError:
        print("[!] Permission denied. Please run this script as Administrator.")
    except FileNotFoundError:
        print("[!] 'secedit' tool not found. Make sure you're running this on a Windows system with secedit available.")
    except Exception as e:
        print(f"[!] An unexpected error occurred: {str(e)}")

export_security_policy()
